// Translated by: Alexandre da Silva <simpsomboy@gmail.com>

jsToolBar.strings = {};
jsToolBar.strings['Strong'] = 'Negrito';
jsToolBar.strings['Italic'] = 'Itálico';
jsToolBar.strings['Underline'] = 'Sublinhado';
jsToolBar.strings['Deleted'] = 'Excluído';
jsToolBar.strings['Code'] = 'Código Inline';
jsToolBar.strings['Heading 1'] = 'Cabeçalho 1';
jsToolBar.strings['Heading 2'] = 'Cabeçalho 2';
jsToolBar.strings['Heading 3'] = 'Cabeçalho 3';
jsToolBar.strings['Unordered list'] = 'Lista não ordenada';
jsToolBar.strings['Ordered list'] = 'Lista ordenada';
jsToolBar.strings['Quote'] = 'Quote';
jsToolBar.strings['Unquote'] = 'Remove Quote';
jsToolBar.strings['Preformatted text'] = 'Texto pré-formatado';
jsToolBar.strings['Wiki link'] = 'Link para uma página Wiki';
jsToolBar.strings['Image'] = 'Imagem';
